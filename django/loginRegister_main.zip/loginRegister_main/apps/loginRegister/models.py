from __future__ import unicode_literals
import re
from django.db import models
import bcrypt

Email_Regex = re.compile(r'^[a-zA-Z0-9\.\+_-]+@[a-zA-Z0-9\._-]+\.[a-zA-Z]*$')
Name_Regex = re.compile(r'^[a-zA-Z]\w+$')

# Create your models here.

class UserManager(models.Manager):
    def validate_registration(self, postData):
        errors = []
        if len(postData['first_name']) < 2 or len(postData['last_name']) < 2:
            errors.append('Names cannot be fewer than 2 characters')
        if not re.match(Name_Regex, postData['first_name']) or not re.match(Name_Regex, postData['last_name']):
            errors.append('Names can have only letters')
        if len(User.objects.filter(email=postData['email'])) > 0:
            errors.append('Email has already been registered')
        if not re.match(Email_Regex, postData['email']):
            errors.append('Invalid email')
        if len(postData['password']) < 8:
            errors.append('Password is too small')
        if not (postData['password'] == postData['confirm_password']):
            errors.append('Passwords dont match')
        if not errors:
            hashing = bcrypt.hashpw((postData['password'].encode()), bcrypt.gensalt(10))
            user = User.objects.create(
                first_name=postData['first_name'],
                last_name=postData['last_name'], 
                email=postData['email'], 
                password=hashing)
            return user
        return errors
    
    def validate_login(self, postData):
        errors = []
        if len(self.filter(email=postData['email'])) > 0:
            user = self.filter(email=postData['email'])[0]
            if not (bcrypt.hashpw(postData['password'].encode(), user.password.encode())):
                errors.append('Incorrect Email/Password')
        else:
            errors.append('Incorrect Email/Password')
        if errors:
            return errors
        return user

class User(models.Model):
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = UserManager()
    def __str__(self):
        return self.email